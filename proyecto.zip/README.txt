Proyecto eva2LopezJorge - Evaluación 2 Programación Back End

Estructura principal:
- eva2LopezJorge_prj/           -> configuración del proyecto Django
- eva2LopezJorge_app/           -> modelo Usuarios y login con perfiles
- eva2Trabajador_app/           -> modelos Afps, Trabajador, Descuentos, Liquidaciones
- static/img/logo.png           -> logo institucional usado en la vista de liquidación

Revisa BD_INSTRUCCIONES.txt para los pasos de creación y conexión de la base de datos MariaDB.
