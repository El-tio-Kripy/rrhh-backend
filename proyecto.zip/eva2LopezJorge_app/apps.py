from django.apps import AppConfig

class Eva2LopezJorgeAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "eva2LopezJorge_app"
