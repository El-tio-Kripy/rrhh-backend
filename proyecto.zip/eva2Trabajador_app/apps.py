from django.apps import AppConfig

class Eva2TrabajadorAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "eva2Trabajador_app"
