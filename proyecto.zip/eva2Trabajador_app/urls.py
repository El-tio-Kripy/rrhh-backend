from django.urls import path

urlpatterns = [
    # Archivo de rutas vacío temporalmente
]
